"use client"

import Navbar from "../src/components/common/Navbar"

export default function SyntheticV0PageForDeployment() {
  return <Navbar />
}